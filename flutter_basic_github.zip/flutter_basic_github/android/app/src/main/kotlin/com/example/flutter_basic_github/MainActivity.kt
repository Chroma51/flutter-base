package com.example.flutter_basic_github

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
